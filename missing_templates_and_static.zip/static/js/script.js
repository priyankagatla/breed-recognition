// script.js — front-end logic for the Breed Recognition UI

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const chooseImageBtn = document.getElementById('chooseImageBtn');
const exampleGrid = document.getElementById('exampleGrid');

const emptyState = document.getElementById('emptyState');
const loadingState = document.getElementById('loadingState');
const resultState = document.getElementById('resultState');
const errorBanner = document.getElementById('errorBanner');

const uploadedImage = document.getElementById('uploadedImage');
const breedName = document.getElementById('breedName');
const confidenceRing = document.getElementById('confidenceRing');
const confidenceValue = document.getElementById('confidenceValue');
const confidenceLabel = document.getElementById('confidenceLabel');
const confidenceMsg = document.getElementById('confidenceMsg');

const infoOrigin = document.getElementById('infoOrigin');
const infoUses = document.getElementById('infoUses');
const infoCharacteristics = document.getElementById('infoCharacteristics');
const infoDescription = document.getElementById('infoDescription');

const uploadAnotherBtn = document.getElementById('uploadAnotherBtn');
const downloadBtn = document.getElementById('downloadBtn');
const shareBtn = document.getElementById('shareBtn');

let lastResult = null;

// ---------------------------------------------------------------------
// Example images (served as static placeholder thumbnails — swap these
// files in static/img/examples/ for real dataset photos any time).
// ---------------------------------------------------------------------
const EXAMPLES = [
  { file: 'gir.jpg', label: 'Gir (Cattle)' },
  { file: 'ongole.jpg', label: 'Ongole (Cattle)' },
  { file: 'murrah.jpg', label: 'Murrah (Buffalo)' },
  { file: 'jaffarabadi.jpg', label: 'Jaffarabadi (Buffalo)' },
  { file: 'kankrej.jpg', label: 'Kankrej (Cattle)' },
  { file: 'nili-ravi.jpg', label: 'Nili-Ravi (Buffalo)' },
];

EXAMPLES.forEach(ex => {
  const img = document.createElement('img');
  img.src = `/static/img/examples/${ex.file}`;
  img.alt = ex.label;
  img.title = `Try example: ${ex.label}`;
  img.addEventListener('click', () => loadExampleImage(ex.file));
  exampleGrid.appendChild(img);
});

async function loadExampleImage(filename) {
  try {
    const res = await fetch(`/static/img/examples/${filename}`);
    const blob = await res.blob();
    const file = new File([blob], filename, { type: blob.type || 'image/jpeg' });
    handleFile(file);
  } catch (err) {
    showError('Could not load the example image.');
  }
}

// ---------------------------------------------------------------------
// Upload interactions: click, drag & drop, file input
// ---------------------------------------------------------------------
chooseImageBtn.addEventListener('click', () => fileInput.click());

fileInput.addEventListener('change', () => {
  if (fileInput.files && fileInput.files[0]) {
    handleFile(fileInput.files[0]);
  }
});

['dragenter', 'dragover'].forEach(evt => {
  dropzone.addEventListener(evt, e => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
});
['dragleave', 'drop'].forEach(evt => {
  dropzone.addEventListener(evt, e => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
  });
});
dropzone.addEventListener('drop', e => {
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

function handleFile(file) {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  if (!validTypes.includes(file.type)) {
    showError('Please upload a JPG, JPEG, or PNG image.');
    return;
  }
  predict(file);
}

// ---------------------------------------------------------------------
// Prediction request
// ---------------------------------------------------------------------
async function predict(file) {
  hideError();
  setState('loading');

  const formData = new FormData();
  formData.append('image', file);

  try {
    const res = await fetch('/predict', { method: 'POST', body: formData });
    const data = await res.json();

    if (!res.ok || data.error) {
      throw new Error(data.error || 'Prediction failed. Please try again.');
    }

    renderResult(data);
    setState('result');
  } catch (err) {
    setState('empty');
    showError(err.message || 'Something went wrong while analyzing the image.');
  }
}

function renderResult(data) {
  lastResult = data;

  uploadedImage.src = data.image_url;
  breedName.textContent = data.breed;

  confidenceValue.textContent = `${data.confidence}%`;
  confidenceRing.style.setProperty('--pct', data.confidence);

  confidenceLabel.textContent = data.confidence_label;
  confidenceMsg.textContent = data.confidence_message;

  infoOrigin.textContent = data.origin;
  infoDescription.textContent = data.description;

  infoUses.innerHTML = '';
  data.uses.forEach(u => {
    const li = document.createElement('li');
    li.textContent = u;
    infoUses.appendChild(li);
  });

  infoCharacteristics.innerHTML = '';
  data.characteristics.forEach(c => {
    const li = document.createElement('li');
    li.textContent = c;
    infoCharacteristics.appendChild(li);
  });
}

function setState(state) {
  emptyState.classList.add('hidden');
  loadingState.classList.add('hidden');
  resultState.classList.add('hidden');

  if (state === 'empty') emptyState.classList.remove('hidden');
  if (state === 'loading') loadingState.classList.remove('hidden');
  if (state === 'result') resultState.classList.remove('hidden');
}

function showError(msg) {
  errorBanner.textContent = msg;
  errorBanner.classList.remove('hidden');
}
function hideError() {
  errorBanner.classList.add('hidden');
}

// ---------------------------------------------------------------------
// Bottom action buttons
// ---------------------------------------------------------------------
uploadAnotherBtn.addEventListener('click', () => {
  fileInput.value = '';
  lastResult = null;
  hideError();
  setState('empty');
});

downloadBtn.addEventListener('click', () => {
  if (!lastResult) return;
  const r = lastResult;
  const lines = [
    'IMAGE BASED BREED RECOGNITION - PREDICTION RESULT',
    '='.repeat(50),
    `Predicted Breed : ${r.breed} (${r.species})`,
    `Confidence      : ${r.confidence}% - ${r.confidence_label}`,
    '',
    `Origin: ${r.origin}`,
    '',
    'Uses:',
    ...r.uses.map(u => `  - ${u}`),
    '',
    'Characteristics:',
    ...r.characteristics.map(c => `  - ${c}`),
    '',
    'Description:',
    r.description,
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `breed_result_${r.breed.replace(/\s+/g, '_')}.txt`;
  a.click();
  URL.revokeObjectURL(url);
});

shareBtn.addEventListener('click', async () => {
  if (!lastResult) return;
  const r = lastResult;
  const shareText = `Breed Prediction: ${r.breed} (${r.species}) - ${r.confidence}% confidence.\nOrigin: ${r.origin}`;

  if (navigator.share) {
    try {
      await navigator.share({ title: 'Breed Prediction Result', text: shareText });
      return;
    } catch (e) { /* user cancelled or unsupported — fall through to clipboard */ }
  }
  try {
    await navigator.clipboard.writeText(shareText);
    alert('Result copied to clipboard!');
  } catch (e) {
    alert(shareText);
  }
});

// Initial state
setState('empty');
